# Loan 360 Calculator

## Mobile-only APK build

This project includes a GitHub Actions workflow.

1. Create a GitHub repository.
2. Upload all files/folders from this project to the repository root.
3. Open the **Actions** tab.
4. Run **Build APK** (or push to main/master).
5. When the workflow finishes, open the workflow run.
6. Download the artifact named **Loan360Calculator-debug-apk**.
7. Extract it and install `app-debug.apk` on Android.

## Calculation rule

Monthly principal = Loan Amount / Number of Months

Monthly interest = Opening Balance × Annual Rate / 360 × 30

Monthly payment = Monthly principal + Monthly interest
