package com.example.loan360

import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.text.NumberFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var amount: TextInputEditText
    private lateinit var rate: TextInputEditText
    private lateinit var months: TextInputEditText
    private lateinit var startMonth: Spinner
    private lateinit var startYear: TextInputEditText
    private lateinit var result: LinearLayout
    private val money = NumberFormat.getCurrencyInstance(Locale("en", "BD")).apply {
        currency = Currency.getInstance("BDT")
        maximumFractionDigits = 2
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 40)
            setBackgroundColor(0xFFF5F7FB.toInt())
        }

        val title = TextView(this).apply {
            text = "Loan 360 Calculator"
            textSize = 28f
            setTextColor(0xFF172033.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(title)

        val sub = TextView(this).apply {
            text = "Reducing balance • 360-day interest basis"
            textSize = 14f
            setTextColor(0xFF667085.toInt())
            setPadding(0, 4, 0, 20)
        }
        root.addView(sub)

        amount = field(root, "Loan Amount (৳)", "60000")
        rate = field(root, "Annual Interest Rate (%)", "13")
        months = field(root, "Loan Period (Months)", "12")

        val monthLabel = TextView(this).apply {
            text = "Starting Month"
            textSize = 14f
            setTextColor(0xFF344054.toInt())
            setPadding(4, 10, 0, 6)
        }
        root.addView(monthLabel)

        startMonth = Spinner(this)
        startMonth.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            DateFormatSymbols().months.filter { it.isNotBlank() })
        startMonth.setSelection(Calendar.getInstance().get(Calendar.MONTH))
        root.addView(startMonth)

        startYear = field(root, "Starting Year", Calendar.getInstance().get(Calendar.YEAR).toString())

        val calculate = Button(this).apply {
            text = "Calculate Repayment Schedule"
            textSize = 16f
            isAllCaps = false
            setOnClickListener { calculate() }
        }
        val bp = LinearLayout.LayoutParams(-1, 58)
        bp.setMargins(0, 20, 0, 18)
        root.addView(calculate, bp)

        result = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        root.addView(result)

        scroll.addView(root)
        setContentView(scroll)
    }

    private fun field(parent: LinearLayout, label: String, value: String): TextInputEditText {
        val layout = TextInputLayout(this).apply {
            hint = label
            boxBackgroundMode = TextInputLayout.BOX_BACKGROUND_OUTLINE
        }
        val edit = TextInputEditText(this).apply {
            setText(value)
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        layout.addView(edit)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 0, 0, 10)
        parent.addView(layout, lp)
        return edit
    }

    private fun calculate() {
        result.removeAllViews()
        val principal = amount.text.toString().toDoubleOrNull()
        val annualRate = rate.text.toString().toDoubleOrNull()
        val n = months.text.toString().toIntOrNull()
        val year = startYear.text.toString().toIntOrNull()

        if (principal == null || annualRate == null || n == null || year == null || principal <= 0 || annualRate < 0 || n <= 0) {
            Toast.makeText(this, "Please enter valid values.", Toast.LENGTH_SHORT).show()
            return
        }

        val monthlyPrincipal = principal / n
        var balance = principal
        var totalInterest = 0.0
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, startMonth.selectedItemPosition)
            set(Calendar.DAY_OF_MONTH, 1)
        }

        addSummary(principal, annualRate, n)
        val tableTitle = TextView(this).apply {
            text = "Repayment Schedule"
            textSize = 21f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFF172033.toInt())
            setPadding(0, 12, 0, 10)
        }
        result.addView(tableTitle)

        repeat(n) { i ->
            val interest = balance * annualRate / 100.0 / 360.0 * 30.0
            val payment = monthlyPrincipal + interest
            balance = (balance - monthlyPrincipal).coerceAtLeast(0.0)
            totalInterest += interest

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(18, 16, 18, 16)
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            val monthName = cal.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.ENGLISH) ?: ""
            val header = TextView(this).apply {
                text = "${i + 1}. $monthName ${cal.get(Calendar.YEAR)}"
                textSize = 18f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(0xFF2563EB.toInt())
            }
            card.addView(header)
            card.addView(line("Opening Balance", money.format(balance + monthlyPrincipal)))
            card.addView(line("Principal", money.format(monthlyPrincipal)))
            card.addView(line("Interest (30/360)", money.format(interest)))
            card.addView(line("Total Payment", money.format(payment)))
            card.addView(line("Closing Balance", money.format(balance)))
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.setMargins(0, 0, 0, 12)
            result.addView(card, lp)
            cal.add(Calendar.MONTH, 1)
        }

        val footer = TextView(this).apply {
            text = "Total Interest: ${money.format(totalInterest)}\nTotal Payable: ${money.format(principal + totalInterest)}"
            textSize = 18f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFF172033.toInt())
            setPadding(4, 14, 4, 8)
        }
        result.addView(footer)
    }

    private fun addSummary(p: Double, r: Double, n: Int) {
        val t = TextView(this).apply {
            text = "Loan Summary\nAmount: ${money.format(p)}   •   Rate: $r%   •   Term: $n months"
            textSize = 16f
            setTextColor(0xFF344054.toInt())
            setPadding(0, 8, 0, 12)
        }
        result.addView(t)
    }

    private fun line(label: String, value: String): TextView =
        TextView(this).apply {
            text = "$label: $value"
            textSize = 14f
            setTextColor(0xFF475467.toInt())
            setPadding(0, 5, 0, 2)
        }
}
